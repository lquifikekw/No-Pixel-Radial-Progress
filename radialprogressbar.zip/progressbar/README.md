# progressbar
NoPixel 3.5 Inspired Progressbar

# Dependencies
qb-core: https://github.com/qbcore-framework/qb-core


# Credits

https://github.com/Project-Sloth/progressbar
